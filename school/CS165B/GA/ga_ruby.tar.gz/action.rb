class Action
  attr_reader :power, :row, :column, :signal
  
  def initialize(power, row, column, signal)
    @power, @row, @column, @signal = power, row, column, signal
  end
end
